#' Create Connection to Pelagic Database on Baseline3. 
#'
#' Create Connection to Pelagic Database on Baseline3.
#' This connection grant permission to select on tables: master, timseries, iccatt2ce, iotccell, wcpfc, iattc. 
#' @param dbuser role name for database
#' @param dbpass database password for role `dbuser`
#' @export
connectPelagic = function(dbuser = "rpackage", dbpass =  "sCPUEdb"){
  require(RPostgreSQL)
  require(RH2) 	
  	dbname = "pelagic"
  	dbhost <- "baseline3.stanford.edu"
  	dbport <- 5432
  	drv <- dbDriver("PostgreSQL") 
  	con <- dbConnect(drv, host=dbhost, port=dbport, dbname=dbname,  user=dbuser, password=dbpass
  	) 
}