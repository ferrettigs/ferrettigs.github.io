#' Generate R polygons from coord in the pelagic database
#'
#' @param coord vector of coords
#' @return an R polygon
#' @export

coord2polygon = function(coord){
	prova = coord
	polygonDat = list()
	for (i in 1:length(prova)){
		x = gregexpr('\\-*[0-9]+\\.*[0-9]*\\,',prova[i],perl=T,fixed=F) # extracts longitudes	
		lon = unlist(regmatches(prova[i],x))
		lon = gsub(",","",lon)
		lon = gsub(" ","",lon)

		y = gregexpr('\\, *\\-*[0-9]+\\.*[0-9]*',prova[i],perl=T)
		lat = unlist(regmatches(prova[i],y))
		lat = gsub(",","",lat)
		lat = gsub(" ","",lat)
		polygonDat[[i]] = list(lon = lon, lat = lat)
	}
	polygonDat
}


