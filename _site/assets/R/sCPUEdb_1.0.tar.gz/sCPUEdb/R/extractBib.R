#' Extract Reference List from DB
#'
#' Script to update the reference list in the website from the database
#' @param conditions specify where clause on the master table selecting for distinct refs
#' @param con connection handle
#' @param fileName name of the output file without extension
#' @return it will output a bib and tex file with file name. A problem with this function is that it does not returns the list of references missing in the aic master bib file. 
#' @export

extractBib = function(con, conditions = "where species = 'Prionace glauca'", fileName="pelagicRefs"){
 	require(xtable)

	data1 <- dbSendQuery(con, statement = paste("select distinct(ref) from master ",conditions,";",sep=""))
	# now fetch data
	bib <- fetch(data1, n = -1)   # extract all rows 
	write(paste("\\cite{",paste(sort(unique(bib$ref)),collapse=","),"}",sep=""),file = paste("../tex/",fileName,".tex",sep="")) # to write
	system(paste("/usr/bin/perl ../perl/extractbib.pl ../tex/",fileName,".tex ../tex/atc.bib ../tex/",fileName,".bib", sep = ""))
}
