#' get Indian Ocean Tuna Commission catch and effort data
#'
#' @param con connection to the sCPUEdb
#' @param Reslat latitude resolution
#' @param Reslon longitude resolution
#' @param fullres if TRUE return full resolution data. That means it returns the data in all resolutions as they were submitted. 
#' @return a data.frame with `lat`, `lon`, `year`, `hooks` and `fleet`; lat and lon refer to the SW corner of pixel. 
#' @export


getIOTCdata = function(con, Reslat = 5, Reslon = 5, fullres = FALSE){


iotc = fetch(dbSendQuery(con, statement = "select fleet, gear, year, monthstart, monthend,   igrid, grid, effort as hooks, effortunits, qualitycode, source from iotccell where effortunits = 'HOOKS';"), n = -1)


iotc$size = substr(iotc$grid,1,1)
iotc$res = ifelse(iotc$size==6,"5*5",ifelse(iotc$size==5,"1*1",ifelse(iotc$size==4,"20*20","10*20")))
if (fullres==FALSE) iotc = iotc[iotc$res==paste(Reslat,"*",Reslon, sep=""),] # else it retains all resolutions, useful for evantually expanding

iotc$lat = as.numeric(substr(iotc$grid,3,4)) # extract latitude
iotc$lon = as.numeric(substr(iotc$grid,5,7)) # extract longitude
iotc$quad = as.numeric(substr(iotc$grid,2,2)) # extract quadrant
	#  change sign to latitude
iotc$lat = ifelse(iotc$quad == 2, iotc$lat*(-1),iotc$lat)


ressplit = strsplit(iotc$res,"\\*")
iotc$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
iotc$reslon = as.numeric(sapply(ressplit,function(x)x[2]))
		
iotc$lat = with(iotc,ifelse(quad %in% c(2,3), lat - reslat, lat))
iotc$lon = with(iotc,ifelse(quad %in% c(3,4), lon - reslon, lon))
# to bring all to SW corner
# there are no duplicates at this stage
if (fullres) iotc = iotc[,c("lat","lon","year","hooks","fleet","res")]  else iotc = iotc[,c("lat","lon","year","hooks","fleet")] 
iotc

}

#' get Indian Ocean Tuna Commission Catch and Effort data
#'
#' @param con connection to the sCPUEdb
#' @param catch species to extract
#' @return a data.frame with `lat`, `lon`, `year`, `hooks` and `fleet`; lat and lon refer to the SW corner of pixel. 
#' @export



getIOTCdataCE = function(con, catch = "bsh_no"){


iotc = fetch(dbSendQuery(con, statement = paste("select fleet, gear, year, monthstart, monthend,   igrid, grid, effort as hooks, effortunits, qualitycode, source,",catch,"  from iotccell where effortunits = 'HOOKS';", sep = "")), n = -1)


iotc$size = substr(iotc$grid,1,1)
iotc$res = ifelse(iotc$size==6,"5*5",ifelse(iotc$size==5,"1*1",ifelse(iotc$size==4,"20*20","10*20")))
if (fullres==FALSE) iotc = iotc[iotc$res==paste(Reslat,"*",Reslon, sep=""),] # else it retains all resolutions, useful for evantually expanding

iotc$lat = as.numeric(substr(iotc$grid,3,4)) # extract latitude
iotc$lon = as.numeric(substr(iotc$grid,5,7)) # extract longitude
iotc$quad = as.numeric(substr(iotc$grid,2,2)) # extract quadrant
	#  change sign to latitude
iotc$lat = ifelse(iotc$quad == 2, iotc$lat*(-1),iotc$lat)


ressplit = strsplit(iotc$res,"\\*")
iotc$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
iotc$reslon = as.numeric(sapply(ressplit,function(x)x[2]))
		
iotc$lat = with(iotc,ifelse(quad %in% c(2,3), lat - reslat, lat))
iotc$lon = with(iotc,ifelse(quad %in% c(3,4), lon - reslon, lon))
# to bring all to SW corner
# there are no duplicates at this stage
iotc = iotc[,c("lat","lon","year","hooks",catch,"fleet","res")]
names(iotc) = c("lat","lon","year","effort","catch","fleet","res") 
iotc

}	

	