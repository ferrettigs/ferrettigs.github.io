
#' get a table from the baseline2 machine not from the database
#'
#' it reads the source files of the database. So it check whether the data has been inputted, in that case the table is in the `data` folder, else it checks into the `datainDB` folder. This is useful to have a more synthetic view of the data populating the tables in the database. They do not include column with missing values.
#' @param Table is the table file to extract from the server
#' @param address location of the data
#' @param ref refcode of the data to explore
#' @param inDB whether the data files have been included in the postgresql database. If the function fails try this option.
#' @export

getTable = function(Table ='Master',address="data/",ref, inDB = FALSE){
 if(inDB) remoteadd = "data/datainDB/" else remoteadd = address
 system(paste("scp francesco@baseline2.stanford.edu:/home/francesco/Baselines/pelagic/",remoteadd,ref,Table,".csv /Users/francesco/Baselines/pelagic/data",sep=""))
 master = read.csv(paste("/Users/francesco/Baselines/pelagic/",address,ref,Table,".csv",sep=""))
 master
}

#' open the pdf file related to ref
#' @param ref code for the publication
#' @export
openPdf = function(ref){
x = system(paste("locate ",ref,".pdf | wc -l",sep=""),intern=TRUE) # checks whether the file is present
x = as.numeric(x) # if it is 0 there is no file
if (x!=0) system(paste("locate ",ref,".pdf |xargs open",sep="")) else {
system(paste("scp francesco@baseline2.stanford.edu:/home/francesco/Baselines/pelagic/pdf/",ref,".pdf /Users/francesco/Baselines/pelagic/pdf",sep=""));
system(paste("open /Users/francesco/Baselines/pelagic/pdf/",ref,".pdf",sep=""));
}

# if there is no file in local than gets the file from remote and stores it in the pdf folder

}

#' get all the species available in the shark CPUE db
#' @param con a connection to teh database. It shoud be run after `connectPelagic`.
#' @export
getSpecies = function(con){
setwd("~/Baselines/pelagic/s")
source("connectPelagic.R")
species = dbSendQuery(con, statement = paste("select distinct species from master where gear like '%pll%';",sep=""))
data1<- fetch(species, n = -1)
species = data1$species[-grep("All Rays|All Sharks|sp.|spp.|group|Rays|Unknown|Other|Unidentified|disaggregate|idae",data1$species)]
species = sort(as.character(species))
species

}


#' Returns a table from any table in the pelagic DB with non-empty columns.
#' @param con connection to the database
#' @param ref refcode of the data
#' @param Table table name of the shark CPUE database
#' @export
getNEmptyCol = function(con,ref,Table = "master"){
	data1<- fetch(dbSendQuery(con, statement = paste("select * from ",Table," where ref = '",ref,"';",sep="")), n = -1)
	m1<-apply(data1,2,function(x)ifelse(is.na(x),0,1))
	data2 = data1[,colSums(m1)>0]
	data2
}

#' `getNEmptyCol` with the option to specify the where clause
#'
#' @export
getNEmptyCol2 = function(con,ref,Table = "master", where = ""){
	data1<- fetch(dbSendQuery(con, statement = paste("select * from ",Table," where ",where," and ref = '",ref,"';",sep="")), n = -1)
	m1<-apply(data1,2,function(x)ifelse(is.na(x),0,1))
	data2 = data1[,colSums(m1)>0]
	data2
}



