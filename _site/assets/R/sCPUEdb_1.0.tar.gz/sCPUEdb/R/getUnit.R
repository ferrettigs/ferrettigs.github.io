#' extract unit from celles with data addresses (e.g. Tab1[,2])
#'
#' @param cell text content of the cell - characteri string
#' @export
getUnit = function(cell){

	#cell = as.character(bluep[1,"effort"])
	parsed = regexpr("\\-\\ ?[a-z]+\\_?[a-z]*",cell,perl=T)
	stp = attributes(parsed)$match.length
	unit = substr(cell,parsed,stp+parsed-1)
	unit = gsub(" |-","",unit)
	unit
}
	