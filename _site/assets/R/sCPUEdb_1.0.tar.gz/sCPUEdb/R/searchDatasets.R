#' Search Data Sets
#'
#' the function searches the datasets identified by geographic polygons in the database. 
#' @param searchBox a search box in the coord format. Default searches studies around Hawaii.  "((-176.57,11.87),(-176.57,29.99),(-135.88,29.99),(-135.88,11.87))"
#' @return a list of refs that can be included in another function.
#' @export
searchDatasets = function(searchBox = "((-176.57,11.87),(-176.57,29.99),(-135.88,29.99),(-135.88,11.87))"){

	require(rgeos)
	spgeom1 = searchBox # hawaii area default
	sp1 = coord2polygon(spgeom1)
	sp1 = as.data.frame(sp1)
	sp1 = matrix(as.numeric(unlist(sp1)),nrow = nrow(sp1), ncol = ncol(sp1))
	sp1 = Polygon(sp1)
	sp1 = Polygons(list(sp1), ID = "target") # from Polygon to Polygons
	sp1 = SpatialPolygons(list(sp1)) # from Polygons to spatialPolygons

	latlong = "+init=epsg:4326"
	proj4string(sp1) = CRS(latlong)



	spgeom2 = fetch(dbSendQuery(con, statement = paste("select coord, ref from master;",sep="")), n = -1)
	spgeom2 = na.omit(spgeom2)

	refs = c()
	for(i in 1:nrow(spgeom2)){

		sp2dat = spgeom2[i,]
		if(sp2dat$coord=="") next
		if(sp2dat$ref %in% c("Yokota.etal.2006","Walsh.etal.2009","Roman-Verdesoto.Zoller.2005","Bornatowski.etal.2011","Courtney.Sigler.2007","Yokota.etal.2009","Everett.Fennessy.2007","Roman-Verdesoto.solo.2005","Bigelow.etal.1999","Francis.etal.2002")) next
		sp2 = coord2polygon(sp2dat$coord)
		sp2 = as.data.frame(sp2)
		if (nrow(sp2)==0) next
		sp2 = matrix(as.numeric(unlist(sp2)),nrow = nrow(sp2), ncol = ncol(sp2))
		sp2 = Polygon(sp2)
		sp2 = Polygons(list(sp2), ID = sp2dat$ref) # from Polygon to Polygons
		sp2 = SpatialPolygons(list(sp2)) # from Polygons to spatialPolygons
		proj4string(sp2) = CRS(latlong)
		if(gIntersects(sp1,sp2)) refs[i] = sp2dat$ref else refs[i] = NA
	}	
	refs = unique(refs)
	refs[!is.na(refs)]
}
